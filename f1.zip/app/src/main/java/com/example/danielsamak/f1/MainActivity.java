package com.example.danielsamak.f1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private EditText txt_1, txt_2, res_num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_1 = (EditText)findViewById(R.id.txt_1);
        txt_2 = (EditText)findViewById(R.id.txt_2);
        res_num = (EditText)findViewById(R.id.res_num);
    }

    public void sumar(View view){
        String valor1=txt_1.getText().toString();
        String valor2=txt_2.getText().toString();
        int nro1=Integer.parseInt(valor1);
        int nro2=Integer.parseInt(valor2);
        int suma= nro1+nro2;
        String resultado = String.valueOf(suma);
        res_num.setText(resultado);
    }
    public void restar(View view){
        String valor1=txt_1.getText().toString();
        String valor2=txt_2.getText().toString();
        int nro1=Integer.parseInt(valor1);
        int nro2=Integer.parseInt(valor2);
        int suma= nro1-nro2;
        String resultado = String.valueOf(suma);
        res_num.setText(resultado);
    }
    public void multiplicar(View view){
        String valor1=txt_1.getText().toString();
        String valor2=txt_2.getText().toString();
        int nro1=Integer.parseInt(valor1);
        int nro2=Integer.parseInt(valor2);
        int suma= nro1*nro2;
        String resultado = String.valueOf(suma);
        res_num.setText(resultado);
    }
    public void dividir(View view){
        String valor1=txt_1.getText().toString();
        String valor2=txt_2.getText().toString();
        int nro1=Integer.parseInt(valor1);
        int nro2=Integer.parseInt(valor2);
        int suma= nro1/nro2;
        String resultado = String.valueOf(suma);
        res_num.setText(resultado);
    }
    public void limpiar (View view){
        String vacio = "";
        txt_1.setText(vacio);
        txt_2.setText(vacio);
        res_num.setText(vacio);
    }
}
